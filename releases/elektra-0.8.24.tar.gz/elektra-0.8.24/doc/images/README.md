# Rendered Images

Rendered images and logos can be found in https://github.com/ElektraInitiative/blobs

## SVG Conversion

https://github.com/shakiba/svgexport

	svgexport circle_with_shadows_and_background.svg circle.png 400:400

