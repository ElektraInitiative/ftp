kdb-check-env-dep -- Checks which mountpoints are influenced by environment variables
=====================================================================================

## SYNOPSIS

`kdb check-env-dep`

## DESCRIPTION

This command checks which mountpoint is influenced by changes to environment variables. `PATH` and `KDB` are skipped for reasons.

## SEE ALSO
- [kdb-mount-list-all-files(7)](kdb-mount-list-all-files.md)
