# Code-generation Examples
