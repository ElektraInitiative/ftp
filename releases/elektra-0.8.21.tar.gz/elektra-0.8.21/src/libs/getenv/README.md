For easier inclusion/exclusion getenv is now a binding and can be found
[here](https://master.libelektra.org/src/bindings/intercept/env).
