# encoding: UTF-8
##
# @file
#
# @brief main module for kdbtools
#
# @copyright BSD License (see LICENSE.md or https://www.libelektra.org)
#
# This module is an extension to the SWIG created wrapper to libelektra tools
#

require '_kdbtools'

module Kdbtools


end

