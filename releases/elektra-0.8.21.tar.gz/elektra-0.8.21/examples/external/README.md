This folder contains examples on how to write applications
using Elektra outside of the Elektra source tree.

[See how to build and run example](tests/shell/check_external.sh)
