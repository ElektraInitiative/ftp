# Template

## Issue

## Constraints

## Assumptions

## Considered Alternatives

## Decision

## Argument

## Implications

## Related decisions

## Notes
