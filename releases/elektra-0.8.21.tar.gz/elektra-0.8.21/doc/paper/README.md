# Citations

Please cite Elektra the following way:

```bib
@article{raab2016elektra,
	doi = {10.21105/joss.00044},
	url = {http://dx.doi.org/10.21105/joss.00044},
	year  = {2016},
	month = {dec},
	publisher = {The Open Journal},
	volume = {1},
	number = {8},
	author = {Markus Raab},
	title = {Elektra: universal framework to access configuration parameters},
	journal = {The Journal of Open Source Software}
}
```

For more information, see:

http://joss.theoj.org/papers/10.21105/joss.00044

