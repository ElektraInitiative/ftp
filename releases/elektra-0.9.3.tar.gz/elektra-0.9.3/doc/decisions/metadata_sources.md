# Metadata Sources

## Problem

If metadata is merged from different sources, metadata from spec might end up somewhere else.

## Constraints

## Assumptions

## Considered Alternatives

## Decision

Do not store metadata in any namespace but spec.

## Rationale

## Implications

## Related Decisions

## Notes
