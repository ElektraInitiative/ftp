# Decisions

## Introduction

Before you write your first decision, read about the [decision process](5_partially_implemented/decision_process.md) and [steps](STEPS.md).

## Meta-Information

Even though they use the decision template, following decisions are not decisions:

- [Template](TEMPLATE.md)
- [Explanations](EXPLANATIONS.md)
