This folder contains information for contributors to Elektra.

- [Documentation Guidelines](documentation.md)
- [Copy on Write](copy_on_write.md)
- [mmapstorage](mmapstorage.md)
- [API](api/) related to API design, maintenance etc.
  Please read if you plan any changes or extensions of the API.
