# Library Directory Structure

## Problem

Currently src/libs/elektra contains the source of several libraries. Each of the libraries should have its own folder.
Furthermore, we need to allow rust source to exist in parallel.

## Constraints

## Assumptions

## Considered Alternatives

## Decision

## Rationale

## Implications

## Related Decisions

## Notes
