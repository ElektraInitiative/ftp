This is a fully working example for how to use Elektra with Maven or Gradle.

Make sure Elektra and the JNA binding are installed correctly.

See [JNA binding](../../../../src/bindings/jna/README.md) for more information.
