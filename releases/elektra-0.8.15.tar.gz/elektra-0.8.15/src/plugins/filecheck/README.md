- infos = Information about the filecheck plugin is in keys below
- infos/author = Thomas Waser <thomas.waser@libelektra.org>
- infos/licence = BSD
- infos/provides =
- infos/needs =
- infos/recommends =
- infos/placements = pregetstorage precommit
- infos/status = maintained tested nodep libc configurable
- infos/metadata =
- infos/description =

## Introduction ##

The filecheck plugin validates files. It tests: encoding, lineendings, BOM, printable characters and null bytes.

## Configuration ##

`check/lineending`
`valid/lineending`
When the `checkLE` key is present, the plugin checks the file for consistent line endings. If you want to validate for a specific line ending you can supply it with the `validLE` key. Valid values are: `CR`, `LF`, `CRLF`, `LFCR`.

`check/encoding`
`valid/encoding`
When the `checkEncoding` key is present, the plugin validates the file encoding supplied by the key `encoding`, or, if not present, defaults to `UTF-8`

`reject/null`
When the `rejectNull` key is present, the plugin rejects the file if a NULL-Byte is found. 

`/reject/bom`
When the `rejectBom` key is present, the plugin rejects the file if any BOM markers are found.

`/reject/unprintable`
When the `rejectUnprintable` key is preset, the plugin rejects the file if an unprintable character is present (except `\r` and `\n`).

