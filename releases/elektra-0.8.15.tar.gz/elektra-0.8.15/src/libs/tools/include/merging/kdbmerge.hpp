/**
 * @file
 *
 * @brief
 *
 * @copyright BSD License (see doc/COPYING or http://www.libelektra.org)
 */

#ifndef KDBMERGE_HPP_
#define KDBMERGE_HPP_



#endif /* KDBMERGE_HPP_ */
