kdb-list-tools(1) - List all external tools available to Elektra
================================================================

## SYNOPSIS

`kdb list-tools`

## DESCRIPTION

This command lists all the externel tools that are available to Elektra.
By default, external tools are located in the `/usr/local/lib/elektra/tool_exec` directory.

The tool itself is extern.
