#ifndef KDBEXTENSION_H
#define KDBEXTENSION_H

#include <kdbmeta.h>
#include <kdbproposal.h>

#endif
