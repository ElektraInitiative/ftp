#ifndef ELEKTRA_PLUGIN_YAJL_ARRAY_H
#define ELEKTRA_PLUGIN_YAJL_ARRAY_H

#include "kdb.h"

int elektraArrayIncName(Key *key);

#endif
