apt-get install liblua5.2-dev libgirepository1.0-dev gobject-introspection lua-lgi-dev python3-gi
