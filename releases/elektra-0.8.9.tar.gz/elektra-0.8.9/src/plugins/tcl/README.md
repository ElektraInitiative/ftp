- infos = Information about the tcl plugin is in keys below
- infos/author = Markus Raab <elektra@libelektra.org>
- infos/licence = BSD
- infos/needs = code
- infos/provides = storage
- infos/placements = setstorage getstorage
- infos/description = Serialize tcl lists

## Introduction ##

This plugin is a storage plugin which write keys to lists in the style of
the Tcl prograaming language.


