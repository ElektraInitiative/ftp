- infos = Information about the doc plugin is in keys below
- infos/author = Markus Raab <markus@libelektra.org>
- infos/licence = BSD
- infos/provides =
- infos/needs =
- infos/recommends = 
- infos/placements =
- infos/status = discouraged experimental -1000000
- infos/metadata =
- infos/description =


## Introduction ##

This plug-in has no functionality. It contains documentation explaining the basic makeup of a function. [The latest version of this documentation can be found on our documentation site.](http://doc.libelektra.org/api/latest/html/group__plugin.html)
