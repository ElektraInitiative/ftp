These are minimal examples how to applications
with elektra outside of elektra.

[See how to build and run example](tests/shell/check_external.sh)
