- infos = Information about hidden plugin is in keys below
- infos/author = Markus Raab <elektra@libelektra.org>
- infos/licence = BSD
- infos/needs =
- infos/provides = 
- infos/placements = postgetstorage presetstorage
- infos/description = Hides keys which start with a .

## Introduction ##

This plugin simply hides Keys whose names start with a `.`.

See keyIsInactive() for more information.
