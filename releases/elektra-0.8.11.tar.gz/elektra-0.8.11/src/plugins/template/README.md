- infos = Information about the template plugin is in keys below
- infos/author = Name <name@libelektra.org>
- infos/licence = BSD
- infos/needs =
- infos/provides =
- infos/placements =
- infos/description =

## Introduction ##

Use this template if you want to start a new
plugin written in C.

## Usage ##

You can use scripts/copy-template
to automatically rename everything to your
plugin name:

	cd src/plugins
	../../scripts/copy-template yourplugin

