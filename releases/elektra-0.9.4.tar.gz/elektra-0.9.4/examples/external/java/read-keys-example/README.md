This is a fully working example for how to use Elektra with Maven.

Make sure Elektra and the jna binding are installed correctly **and**
the files are known by `mvn`. Unfortunately, it is not yet uploaded
on [Maven Central Repository](https://maven.apache.org/repository/guide-central-repository-upload.html),
contributions are welcomed.

See [/src/bindings/jna/README.md](JNA binding) for more information.
