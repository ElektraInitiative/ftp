- infos =
- infos/author = Thomas Wahringer <waht@libelektra.org>
- infos/licence = BSD
- infos/status =
- infos/provides =
- infos/description =

# Example I/O Binding

This directory contains a complete example of an I/O binding for documentation
purposes.
This binding is not functional.
