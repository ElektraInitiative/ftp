#!/bin/sh

ldconfig
