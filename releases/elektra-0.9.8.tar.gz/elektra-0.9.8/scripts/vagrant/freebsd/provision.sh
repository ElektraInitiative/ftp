#!/bin/csh

pkg install -y \
	bison \
	cmake \
	git \
	libgit2 \
	ninja \
	yajl \
	yaml-cpp
