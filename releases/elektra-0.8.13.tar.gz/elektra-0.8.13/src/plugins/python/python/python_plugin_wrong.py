class ElektraPluginFoo(object):
	pass
