- infos = Information about the python plugin is in keys below
- infos/author = Manuel Mausz <manuel-elektra@mausz.at>
- infos/licence = BSD
- infos/needs =
- infos/provides =
- infos/placements =
- infos/description = magic things require magic plugins

The plugin uses Python to do magic things.

## Deprecation

It is recommended to use [python3](../python/README.md).

## DISCLAIMER

Note, this is a technical preview. It might have severe bugs
and the API might change in the future.
