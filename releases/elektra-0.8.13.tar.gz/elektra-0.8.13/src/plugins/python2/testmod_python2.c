/*
 * \copydoc python.cpp
 */

#include "../python/testmod_python.c"
