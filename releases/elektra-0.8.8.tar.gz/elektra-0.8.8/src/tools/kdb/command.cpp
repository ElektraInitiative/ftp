#include <command.hpp>

Command::~Command()
{}
