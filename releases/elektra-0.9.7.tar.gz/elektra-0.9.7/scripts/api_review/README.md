# Elektra API Review Template Script

This python script generates new review files from the given template.
