Copy your libeelektra4j-VERSION.jar file to [this](lib) directory. The same jar name should be specified in the pom.xml file [here](pom.xml) -- both in systemPath and version xml elements.
