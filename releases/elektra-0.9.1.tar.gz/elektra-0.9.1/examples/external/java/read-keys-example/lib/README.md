Copy your libeelektra4j-VERSION.jar file to this directory.
