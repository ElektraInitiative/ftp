# Template

## Problem

## Constraints

## Assumptions

## Considered Alternatives

## Decision

## Rationale

## Implications

## Related Decisions

## Notes
