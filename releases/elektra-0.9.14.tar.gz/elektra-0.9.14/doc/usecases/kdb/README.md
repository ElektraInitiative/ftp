# Use cases for KDB

This folder contains the use cases for the Key Database (KDB).
These primarily are the basis for `libelektra-kdb`, but may also influence other things like, e.g., the high-level API `libelektra-highlevel`.

The KDB is primarily a system for storing application configuration data.
The individual use cases provide details for this high-level use case.
