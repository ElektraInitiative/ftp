- infos =
- infos/author = Manuel Mausz <manuel-elektra@mausz.at>
- infos/status = deprecated
- infos/provides = gi
- infos/description =

# GI Lua

This binding is deprecated, please use `swig_lua` instead.

## Dependencies

    apt-get install liblua5.2-dev libgirepository1.0-dev gobject-introspection lua-lgi-dev
