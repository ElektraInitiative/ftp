#include "types.hpp"

namespace elektra
{

Type::~Type()
{}

}
