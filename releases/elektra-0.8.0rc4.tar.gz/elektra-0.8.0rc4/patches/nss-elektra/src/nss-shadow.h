/*
 * nss-shadow.h for nss-elektra.
*/

/* Svn stuff
$Id: nss-shadow.h 40 2004-11-26 23:25:09Z rayman $
$LastChangedBy: rayman $
*/


#ifndef _HAVE_NSS_ELEKTRA_SHADOW_H
#define _HAVE_NSS_ELEKTRA_SHADOW_H


#endif /* _HAVE_NSS_ELEKTRA_SHADOW_H */
