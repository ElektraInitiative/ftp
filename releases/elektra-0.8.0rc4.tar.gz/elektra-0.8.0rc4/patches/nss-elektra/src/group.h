/*
 * group.h for nss-registry.
*/

/* Svn stuff
$Id: group.h 40 2004-11-26 23:25:09Z rayman $
$LastChangedBy: rayman $
*/


#ifndef _HAVE_NSS_ELEKTRA_GROUP_H
#define _HAVE_NSS_ELEKTRA_GROUP_H


#endif /* _HAVE_NSS_ELEKTRA_GROUP_H */
