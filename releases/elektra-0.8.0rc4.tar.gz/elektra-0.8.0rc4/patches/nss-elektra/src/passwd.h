/*
 * Passwd.h for nss-elektra.
*/

/* Svn stuff
$Id: passwd.h 40 2004-11-26 23:25:09Z rayman $
$LastChangedBy: rayman $
*/


#ifndef _HAVE_NSS_ELEKTRA_PASSWD_H
#define _HAVE_NSS_ELEKTRA_PASSWD_H


#endif /* _HAVE_NSS_ELEKTRA_PASSWD_H */
