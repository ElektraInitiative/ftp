aclocal
autoconf
autoheader
libtoolize --copy --force
automake --add-missing --copy --gnu
