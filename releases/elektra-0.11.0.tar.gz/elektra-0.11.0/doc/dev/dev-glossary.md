# Developer's glossary of Elektra
