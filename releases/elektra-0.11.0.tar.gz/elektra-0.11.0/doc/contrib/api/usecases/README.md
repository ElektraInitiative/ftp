Files in this directory describe how the various use cases are implemented in the API.
