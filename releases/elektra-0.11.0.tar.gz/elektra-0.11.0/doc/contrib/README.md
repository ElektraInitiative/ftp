This folder contains information for contributors to Elektra.

- [Documentation Guidelines](documentation.md)
- [Contributor's Glossary](contrib-glossary.md)
- [Copy on Write](copy_on_write.md)
- [mmapstorage](mmapstorage.md)
- [Session Recording](recording.md)
- [API](api/) related to API design, maintenance etc.
  Please read if you plan any changes or extensions of the API.
