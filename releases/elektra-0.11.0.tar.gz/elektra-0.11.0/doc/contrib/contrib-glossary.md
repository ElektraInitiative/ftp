# Contributor's glossary of Elektra

- **Change Tracking**:
  mechanism to detect changes that were made to keys in between `kdbGet` and `kdbSet` calls
