# TEMPLATE

## Problem

## Constraints

1.
2.
3.

## Assumptions

1.
2.
3.

## Solutions

### Alternative A

### Alternative B

### Alternative C

## Decision

## Rationale

## Implications

-
-
-

## Related Decisions

- []()
- []()
- []()

## Notes
