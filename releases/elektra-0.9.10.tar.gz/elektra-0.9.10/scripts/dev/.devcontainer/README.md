This devcontainer folder is specifically for visual studio code developers. Nonetheless you can also take advantage of the Dockerfile only if you are not using vscode. This Dockerfile is inspired after GETSTARTED.md

## For vscode users

If you copy this folder to your root working directory and install the extension Remote-Containers(ms-vscode-remote.remote-containers), you can start your development container.

## For other users

You can basically just spin up the docker container using the Dockerfile.
