# Script Testing

## Considered Alternatives

* http://pythonpaste.org/scripttest/
 + easy to work with
 - can only trace a single directory (would not work with /etc + ~)
 - extra dependency not in any distro

* robotframework
 - integration with cmake?
 - does not allow to capture stdout, stderr + return code
