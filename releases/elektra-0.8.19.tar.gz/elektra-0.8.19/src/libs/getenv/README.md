For easier inclusion/exclusion getenv is now a binding and can be found
[here](http://tree.libelektra.org/src/bindings/intercept/env).
