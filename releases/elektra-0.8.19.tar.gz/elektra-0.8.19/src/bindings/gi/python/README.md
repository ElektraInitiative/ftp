# GI Python #

This binding is deprecated, please use `swig_python` instead.

## Dependencies ##

	apt-get install libgirepository1.0-dev gobject-introspection python3-gi
