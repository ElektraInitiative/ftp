# glib #

Provides glib bindings for Elektra.

Are used by gsettings and GI bindings.
