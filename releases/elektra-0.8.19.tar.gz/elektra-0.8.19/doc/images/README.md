https://github.com/shakiba/svgexport

	svgexport circle_with_shadows_and_background.svg circle.png 400:400
