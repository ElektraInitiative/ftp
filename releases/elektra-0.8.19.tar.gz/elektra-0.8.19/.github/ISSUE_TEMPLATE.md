Please remove this template if you have
a question or proposal and do not want
to report an issue.

# Describe what you wanted to do

# Describe what you expected

# Describe what actually happened

# System Information

- Elektra Version: master
- Versions of other relevant software?

# Further Log Files and Output
